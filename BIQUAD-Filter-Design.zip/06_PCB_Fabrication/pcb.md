# 06 – PCB Fabrication

PCB Design Highlights:

- 4-layer design with inner ground planes
- Decoupling caps near ICs
- Use of stitching vias and fencing vias for shielding
- ESD protection for Op-Amps using TVS diodes

All design files are created in KiCad.