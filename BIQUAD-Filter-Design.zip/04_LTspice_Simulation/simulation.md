# 04 – LTspice Simulation

This section contains simulations for multiple filter types:

- Frequency response analysis
- Step response for Low Pass, High Pass, Band Pass, and Band Stop filters

Simulation files demonstrate behavior with Q=1 and Q=10 and use standard LTspice component models.