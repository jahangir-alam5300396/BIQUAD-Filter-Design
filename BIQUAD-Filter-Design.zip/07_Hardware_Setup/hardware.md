# 07 – Hardware Setup

Images of the fully assembled BIQUAD filter hardware using:

- ASLK Pro board
- Red Pitaya STEMlab for signal generation and analysis
- Oscilloscope traces for verification

All test setups validate filter behavior as expected.