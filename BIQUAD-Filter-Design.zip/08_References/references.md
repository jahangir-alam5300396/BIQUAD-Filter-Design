# 08 – References

- Analog Devices: A Beginner’s Guide to Filter Topologies
- Electronics Tutorials: Sallen-Key Filters
- Systemtheorie, Signale und Systeme by M. Buß
- ECStudio: Types of Filters
- StackExchange Discussions on IIR filters

Also includes lecture scripts and diagrams from HSB Bremen's ILIAS platform.